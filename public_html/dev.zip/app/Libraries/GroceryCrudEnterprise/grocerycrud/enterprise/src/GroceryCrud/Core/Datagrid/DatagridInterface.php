<?php
namespace GroceryCrud\Core\Datagrid;

interface DatagridInterface
{
	public function getColumns();
}